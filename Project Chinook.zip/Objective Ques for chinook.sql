-- Objective Question 1
-- Check for duplicate records in all tables

SELECT 'album' AS TableName, COUNT(*) AS DuplicateCount FROM album GROUP BY album_id, title, artist_id HAVING COUNT(*) > 1
UNION ALL
SELECT 'artist', COUNT(*) FROM artist GROUP BY artist_id, name HAVING COUNT(*) > 1
UNION ALL
SELECT 'customer', COUNT(*) FROM customer GROUP BY customer_id, first_name, last_name, email HAVING COUNT(*) > 1
UNION ALL
SELECT 'employee', COUNT(*) FROM employee GROUP BY employee_id, first_name, last_name, title, birthdate HAVING COUNT(*) > 1
UNION ALL
SELECT 'invoice', COUNT(*) FROM invoice GROUP BY invoice_id, customer_id, invoice_date HAVING COUNT(*) > 1
UNION ALL
SELECT 'invoice_line', COUNT(*) FROM invoice_line GROUP BY invoice_line_id, invoice_id, track_id HAVING COUNT(*) > 1
UNION ALL
SELECT 'media_type', COUNT(*) FROM media_type GROUP BY media_type_id, name HAVING COUNT(*) > 1
UNION ALL
SELECT 'playlist', COUNT(*) FROM playlist GROUP BY playlist_id, name HAVING COUNT(*) > 1
UNION ALL
SELECT 'playlist_track', COUNT(*) FROM playlist_track GROUP BY playlist_id, track_id HAVING COUNT(*) > 1
UNION ALL
SELECT 'track', COUNT(*) FROM track GROUP BY track_id, name, album_id, media_type_id, genre_id HAVING COUNT(*) > 1
UNION ALL
SELECT 'genre', COUNT(*) FROM genre GROUP BY genre_id, name HAVING COUNT(*) > 1;

-- SET SQL_SAFE_UPDATES = 0;

-- Fill NULL values in all tables
UPDATE customer SET company = COALESCE(company, 'Unknown') WHERE company IS NULL;
UPDATE customer SET state = COALESCE(state, 'Unknown') WHERE state IS NULL;
UPDATE customer SET postal_code = COALESCE(postal_code, '000000') WHERE postal_code IS NULL;
UPDATE customer SET phone = COALESCE(phone, 'Not Provided') WHERE phone IS NULL;
UPDATE customer SET fax = COALESCE(fax, 'Not Provided') WHERE fax IS NULL;
UPDATE employee SET reports_to = COALESCE(reports_to, 0) WHERE reports_to IS NULL;
UPDATE track SET composer = COALESCE(composer, 'Unknown') WHERE composer IS NULL;

-- Objective Question 2
-- Find the top-selling tracks and top artist in the USA and identify their most famous genres.
Select
	t.name as TrackName,
    art.name as ArtistName,
    g.name as GenreName,
    sum(i.total) as Total_Sales
from
	invoice_line il
join invoice i on il.invoice_id = i.invoice_id
join customer c on i.customer_id = c.customer_id
join track t on il.track_id = t.track_id
join genre g on t.genre_id = g.genre_id
join album alb on t.album_id = alb.album_id
join artist art on art.artist_id = alb.artist_id
where
	c.country = 'USA'
group by
	1,2,3
Order by
	Total_Sales desc
Limit 10;

-- Objective Question 3
-- What is the customer demographic breakdown (age, gender, location) of Chinook's customer base?

Select
	country,
    count(customer_id) as TotalCustomers
from
	 customer
group by
	1;

-- Objective Question 4
-- Calculate the total revenue and number of invoices for each country, state, and city

Select
	billing_country,
    billing_state,
    billing_city,
    sum(total) as Total_Revenue,
    count(invoice_id) as Invoice_Count
from            
	invoice
group by
	1,2,3
Order by
	Total_Revenue desc,
    Invoice_Count desc;
    
-- Query for Total Revenue & Invoice Count by Country
    SELECT 
    billing_country,
    SUM(total) AS total_revenue,
    COUNT(invoice_id) AS invoice_count
FROM invoice
GROUP BY billing_country
ORDER BY total_revenue DESC, invoice_count DESC;

-- 2. Query for Total Revenue & Invoice Count by State
SELECT 
    billing_country,
    COALESCE(billing_state, 'Unknown') AS billing_state, 
    SUM(total) AS total_revenue,
    COUNT(invoice_id) AS invoice_count
FROM invoice
GROUP BY billing_country, billing_state
ORDER BY total_revenue DESC, invoice_count DESC;

-- 3. Query for Total Revenue & Invoice Count by City
    SELECT 
    billing_country,
    COALESCE(billing_state, 'Unknown') AS billing_state, 
    billing_city,
    SUM(total) AS total_revenue,
    COUNT(invoice_id) AS invoice_count
FROM invoice
GROUP BY billing_country, billing_state, billing_city
ORDER BY total_revenue DESC, invoice_count DESC;


-- Objective Question 5
-- Find the top 5 customers by total revenue in each country
With calc as
(
Select
	c.customer_id,
    c.country,
	concat(c.first_name," ",c.last_name) as Customer_Name,
    sum(total) as Total_Revenue,
    rank() over(partition by c.country order by sum(total)) as rnk
from
	customer c join invoice i on c.customer_id = i.customer_id
group by
	1,2,3
)
Select
	customer_id,
    country,
	Customer_Name,
    Total_Revenue
from
	calc
where
	rnk <=5

Order by
	country,rnk;
    
    
    -- question 6
    -- Identify the top-selling track for each customer
WITH TrackSales AS (
    SELECT 
        c.customer_id,
        CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
        t.track_id,
        t.name AS track_name,
        SUM(il.quantity) AS total_quantity,
        ROW_NUMBER() OVER (PARTITION BY c.customer_id ORDER BY SUM(il.quantity) DESC) AS rnk
    FROM customer c
    JOIN invoice i ON c.customer_id = i.customer_id
    JOIN invoice_line il ON i.invoice_id = il.invoice_id
    JOIN track t ON il.track_id = t.track_id
    GROUP BY c.customer_id, c.first_name, c.last_name, t.track_id, t.name
)
SELECT 
    customer_name,
    track_name,
    total_quantity
FROM TrackSales
WHERE rnk = 1
ORDER BY total_quantity desc;




-- Objective Question 7
-- Are there any patterns or trends in customer purchasing behavior (e.g., frequency of purchases, preferred payment methods, average order value)?


WITH CustomerStats AS (
    SELECT 
        c.customer_id,
        CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
        COUNT(i.invoice_id) AS total_purchases,
        DATE_FORMAT(MIN(i.invoice_date), '%d-%m-%Y') AS first_purchase,
        DATE_FORMAT(MAX(i.invoice_date),'%d-%m-%Y') AS last_purchase,
        TIMESTAMPDIFF(YEAR, MIN(i.invoice_date), MAX(i.invoice_date)) AS years_between_purchases,
        TIMESTAMPDIFF(MONTH, MIN(i.invoice_date), MAX(i.invoice_date)) % 12 AS months_between_purchases,
        TIMESTAMPDIFF(DAY, MIN(i.invoice_date), MAX(i.invoice_date)) % 30 AS days_between_purchases,
        SUM(i.total) AS total_spent,
        ROUND(AVG(i.total), 2) AS avg_order_value,
        i.billing_country
    FROM customer c
    JOIN invoice i ON c.customer_id = i.customer_id
    GROUP BY c.customer_id,i.billing_country
)


SELECT 
    customer_name,
    total_purchases,
    first_purchase,
    last_purchase,
    CONCAT(years_between_purchases, ' Years, ', 
           months_between_purchases, ' Months, ', 
           days_between_purchases, ' Days') AS purchase_duration,
    total_spent,
    avg_order_value,
    CASE
        WHEN total_spent > 100 THEN 'High-Value Customer'
        WHEN total_spent BETWEEN 50 AND 100 THEN 'Medium-Value Customer'
        ELSE 'Low-Value Customer'
    END AS customer_segment,
    billing_country
FROM CustomerStats
ORDER BY total_spent DESC;

-- Question 8
-- What is the customer churn rate?

WITH CustomerActivity AS (
    SELECT 
        c.customer_id,
        MAX(i.invoice_date) AS last_purchase_date
    FROM customer c
    JOIN invoice i ON c.customer_id = i.customer_id
    GROUP BY c.customer_id
),
ChurnedCustomers AS (
    SELECT 
        COUNT(*) AS churned_customers,
        (SELECT COUNT(DISTINCT customer_id) FROM customer) AS total_customers,
        ROUND((COUNT(*) / (SELECT COUNT(DISTINCT customer_id) FROM customer)) * 100, 2) AS churn_rate
    FROM CustomerActivity
    WHERE last_purchase_date < DATE_SUB((SELECT MAX(invoice_date) FROM invoice), INTERVAL 6 MONTH)
)
SELECT * FROM ChurnedCustomers;


-- Question 9
-- Calculate the percentage of total sales contributed by each genre in the USA and 
-- identify the best-selling genres and artists.

WITH GenreSales AS (
    SELECT 
        g.genre_id,
        g.name AS genre_name,
		SUM(i.total) AS total_sales
    FROM invoice_line il
    JOIN track t ON il.track_id = t.track_id
    JOIN genre g ON t.genre_id = g.genre_id
    JOIN invoice i ON il.invoice_id = i.invoice_id
    WHERE i.billing_country = 'USA'
    GROUP BY g.genre_id, g.name
),
TotalSales AS (
    SELECT SUM(total_sales) AS overall_sales FROM GenreSales
),
BestSellingArtists AS (
    SELECT 
        ar.name AS artist_name,
        SUM(i.total) AS total_sales
    FROM invoice_line il
    JOIN track t ON il.track_id = t.track_id
    JOIN album al ON t.album_id = al.album_id
    JOIN artist ar ON al.artist_id = ar.artist_id
    JOIN invoice i ON il.invoice_id = i.invoice_id
    WHERE i.billing_country = 'USA'
    GROUP BY ar.artist_id, ar.name
    ORDER BY total_sales DESC
    LIMIT 10
)
SELECT 
    'Genre' AS category,
    gs.genre_name AS name,
    gs.total_sales,
    ROUND((gs.total_sales / ts.overall_sales) * 100, 2) AS sales_percentage
FROM GenreSales gs, TotalSales ts

UNION ALL

SELECT 
    'Artist' AS category,
    ba.artist_name AS name,
    ba.total_sales,
    NULL AS sales_percentage
FROM BestSellingArtists ba

ORDER BY category DESC, total_sales DESC;

-- Objective Ques 10
-- Find customers who have purchased tracks from at least 3 different genres

with customer_genre_count as
(
	select
		c.customer_id,
		concat(first_name," ",last_name) as cust_name,
		count( distinct g.genre_id) as genre_count
	from
		customer c
		join invoice i on c.customer_id = i.customer_id
        join invoice_line il on i.invoice_id = il.invoice_id
        join track t on il.track_id = t.track_id
        join genre g on t.genre_id = g.genre_id
	group by
		customer_id,cust_name
)
select
	customer_id,
    cust_name,
    genre_count
from
	customer_genre_count
where
	genre_count >= 3
order by
	genre_count desc;

-- Objective Question 11
-- Rank genres based on their sales performance in the USA

with genre_rank as
(
	select
        g.name as genre_name,
		sum(i.total) as sales
	from
		customer c
		join invoice i on c.customer_id = i.customer_id
        join invoice_line il on i.invoice_id = il.invoice_id
        join track t on il.track_id = t.track_id
        join genre g on t.genre_id = g.genre_id
	where
		c.country = 'USA'
	group by
		g.name
)

Select
	genre_name,
    sales,
    dense_rank() over (order by sales desc ) as rnk
from
	genre_rank;
    
    -- Objective Question 12
    -- Identify customers who have not made a purchase in the last 3 months
    
  with Latest_trans as
  (
  Select
		c.customer_id,
        concat(c.first_name, " ",c.last_name) as customer_name,
       max(i.invoice_date) as latest_transaction
	from
		customer c
        join invoice i on c.customer_id = i.customer_id
		
	group by
			c.customer_id, customer_name
)

Select
	customer_id,
    customer_name,
    date_format(latest_transaction,'%d-%m-%Y') as latest_transaction
from
	Latest_trans
WHERE 
	latest_transaction >= (SELECT MAX(invoice_date) FROM invoice) - INTERVAL 3 MONTH
    or
		latest_transaction is null
order by
	latest_transaction asc;
    
select
	*
from
	track