-- Subjective Questions for project Chinook
-- Question 1
-- Recommend the three albums from the new record label that should be prioritised for advertising and
-- promotion in the USA based on genre sales analysis.
 WITH GenreSales AS (
    SELECT 
        g.genre_id,
        g.name AS genre_name,
        SUM(i.total) AS genre_total_sales
    FROM invoice_line il
    JOIN track t ON il.track_id = t.track_id
    JOIN genre g ON t.genre_id = g.genre_id
    JOIN invoice i ON il.invoice_id = i.invoice_id
    WHERE i.billing_country = 'USA'
    GROUP BY g.genre_id, g.name
),
TopGenres AS (
    SELECT genre_id, genre_name
    FROM GenreSales
    ORDER BY genre_total_sales DESC
    LIMIT 3  -- Select the top 3 best-selling genres
),
AlbumSales AS (
    SELECT 
        al.album_id,
        al.title AS album_title,
        ar.name AS artist_name,
        g.name AS genre_name,
        SUM(i.total) AS album_total_sales
    FROM invoice_line il
    JOIN track t ON il.track_id = t.track_id
    JOIN album al ON t.album_id = al.album_id
    JOIN artist ar ON al.artist_id = ar.artist_id
    JOIN genre g ON t.genre_id = g.genre_id
    JOIN invoice i ON il.invoice_id = i.invoice_id
    WHERE i.billing_country = 'USA'
    GROUP BY al.album_id, al.title, ar.name, g.name
),
TopAlbums AS (
    SELECT 
        a.album_id,
        a.album_title,
        a.artist_name,
        a.genre_name,
        a.album_total_sales
    FROM AlbumSales a
    JOIN TopGenres tg ON a.genre_name = tg.genre_name
    ORDER BY a.album_total_sales DESC
    LIMIT 3  -- Select the top 3 albums from the best-selling genres
)
SELECT * FROM TopAlbums;

-- Subjective Question 2
-- Determine the top-selling genres in countries other than the USA and
-- identify any commonalities or differences.

WITH GenreSales AS (
    SELECT 
        g.name AS genre_name,
        i.billing_country,
        SUM(i.total) AS total_revenue,  -- Using total from the invoice table
        COUNT(il.invoice_line_id) AS total_tracks_sold
    FROM invoice i
    JOIN invoice_line il ON i.invoice_id = il.invoice_id
    JOIN track t ON il.track_id = t.track_id
    JOIN genre g ON t.genre_id = g.genre_id
    WHERE i.billing_country <> 'USA'  -- Exclude the USA
    GROUP BY g.name, i.billing_country
),
RankedGenres AS (
    SELECT 
        genre_name,
        billing_country,
        total_revenue,
        total_tracks_sold,
        RANK() OVER (PARTITION BY billing_country ORDER BY total_revenue DESC) AS genre_rank
    FROM GenreSales
)
SELECT 
    billing_country,
    genre_name,
    total_revenue,
    total_tracks_sold
FROM RankedGenres
WHERE genre_rank = 1  -- Fetch only the top-selling genre per country
ORDER BY billing_country;

-- Subjective Question 3
-- Customer Purchasing Behavior Analysis: How do the purchasing habits (
-- frequency, basket size, spending amount) of long-term customers differ from those of new customers? 
-- What insights can these patterns provide about customer loyalty and retention strategies?

WITH CustomerPurchaseStats AS (
    SELECT 
        c.customer_id,
        CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
        COUNT(i.invoice_id) AS purchase_frequency,
        AVG(i.total) AS avg_spending_per_order,
        SUM(i.total) AS total_spent,
        DATE(MIN(i.invoice_date)) AS first_purchase_date,
        DATE(MAX(i.invoice_date)) AS last_purchase_date,
        DATEDIFF('2020-12-30', DATE(MIN(i.invoice_date))) AS customer_lifespan_days  -- Compare against Dec 30, 2020
    FROM customer c
    JOIN invoice i ON c.customer_id = i.customer_id
    GROUP BY c.customer_id
),
CustomerType AS (
    SELECT 
        customer_id,
        customer_name,
        purchase_frequency,
        avg_spending_per_order,
        total_spent,
        first_purchase_date,
        last_purchase_date,
        customer_lifespan_days,
        CASE 
            WHEN customer_lifespan_days > 365 THEN 'Long-Term Customer'
            ELSE 'New Customer'
        END AS customer_type
    FROM CustomerPurchaseStats
)
SELECT 
    customer_type,
    COUNT(customer_id) AS customer_count,
    ROUND(AVG(purchase_frequency), 2) AS avg_purchase_frequency,
    ROUND(AVG(avg_spending_per_order), 2) AS avg_order_value,
    ROUND(AVG(total_spent), 2) AS avg_total_spent
FROM CustomerType
GROUP BY customer_type;

-- question 4
-- Product Affinity Analysis: Which music genres, artists, or albums are frequently purchased together
-- by customers? How can this information guide product recommendations and cross-selling initiatives?
WITH CustomerPurchases AS (
    SELECT 
        i.customer_id,
        g.name AS genre_name,
        ar.name AS artist_name,
        al.title AS album_title,
        COUNT(il.track_id) AS purchase_count
    FROM invoice i
    JOIN invoice_line il ON i.invoice_id = il.invoice_id
    JOIN track t ON il.track_id = t.track_id
    JOIN album al ON t.album_id = al.album_id
    JOIN artist ar ON al.artist_id = ar.artist_id
    JOIN genre g ON t.genre_id = g.genre_id
    GROUP BY i.customer_id, g.name, ar.name, al.title
),
GenreAffinity AS (
    SELECT 
        cp1.genre_name AS genre_1,
        cp2.genre_name AS genre_2,
        COUNT(*) AS frequency
    FROM CustomerPurchases cp1
    JOIN CustomerPurchases cp2 
        ON cp1.customer_id = cp2.customer_id 
        AND cp1.genre_name < cp2.genre_name  -- Prevent duplicate pairs
    GROUP BY cp1.genre_name, cp2.genre_name
),
ArtistAffinity AS (
    SELECT 
        cp1.artist_name AS artist_1,
        cp2.artist_name AS artist_2,
        COUNT(*) AS frequency
    FROM CustomerPurchases cp1
    JOIN CustomerPurchases cp2 
        ON cp1.customer_id = cp2.customer_id 
        AND cp1.artist_name < cp2.artist_name
    GROUP BY cp1.artist_name, cp2.artist_name
),
AlbumAffinity AS (
    SELECT 
        cp1.album_title AS album_1,
        cp2.album_title AS album_2,
        COUNT(*) AS frequency
    FROM CustomerPurchases cp1
    JOIN CustomerPurchases cp2 
        ON cp1.customer_id = cp2.customer_id 
        AND cp1.album_title < cp2.album_title
    GROUP BY cp1.album_title, cp2.album_title
)
SELECT * FROM GenreAffinity ORDER BY frequency DESC; -- Change to ArtistAffinity or AlbumAffinity for other analysis

-- Question 5
-- Regional Market Analysis: Do customer purchasing behaviors and churn rates vary across different
-- geographic regions or store locations? How might these correlate with local demographic or economic factors?


WITH recent_purchases AS (
    SELECT customer_id, MAX(invoice_date) AS last_purchase_date
    FROM invoice
    GROUP BY customer_id
),
churned_customers AS (
    SELECT 
        c.country, 
        COUNT(DISTINCT c.customer_id) AS churned_count
    FROM customer c
    JOIN recent_purchases rp ON c.customer_id = rp.customer_id
    WHERE rp.last_purchase_date < DATE_SUB(
        (SELECT MAX(invoice_date) FROM invoice), INTERVAL 6 MONTH
    )
    GROUP BY c.country
)
SELECT 
    c.country, 
    COUNT(DISTINCT c.customer_id) AS total_customers,
    SUM(i.total) AS total_revenue,
    COALESCE(MAX(cc.churned_count), 0) AS churned_customers, 
    ROUND((COALESCE(MAX(cc.churned_count), 0) / COUNT(DISTINCT c.customer_id)) * 100, 2) AS churn_rate
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
LEFT JOIN churned_customers cc ON c.country = cc.country
GROUP BY c.country
ORDER BY total_revenue DESC;

-- Question 6
-- Customer Risk Profiling: Based on customer profiles (age, gender, location, purchase history),
-- which customer segments are more likely to churn or pose a higher risk of reduced spending?
-- What factors contribute to this risk?

WITH CustomerPurchaseHistory AS (
    SELECT 
        c.customer_id,
        c.country,  -- Using c.country for region
        COUNT(i.invoice_id) AS purchase_frequency,
        SUM(i.total) AS total_spent,
        AVG(i.total) AS avg_spending_per_order,
        MAX(i.invoice_date) AS last_purchase_date
    FROM customer c
    JOIN invoice i ON c.customer_id = i.customer_id
    GROUP BY c.customer_id, c.country
),
ChurnRisk AS (
    SELECT 
        customer_id,
        country,
        CASE 
            WHEN DATEDIFF((SELECT MAX(invoice_date) FROM invoice), last_purchase_date) > 180 THEN 'High Risk'  -- No purchase in the last 6 months
            WHEN purchase_frequency >= 3 AND total_spent >= 100 AND total_spent <= 500 THEN 'Moderate Risk'  -- Moderate spending with higher frequency
            WHEN purchase_frequency < 3 OR total_spent < 100 THEN 'Low Risk'  -- Low purchase frequency or low spending
            ELSE 'Low Risk'  -- Otherwise, consider as low risk
        END AS risk_level
    FROM CustomerPurchaseHistory
)
SELECT 
    c.country,
    COUNT(DISTINCT c.customer_id) AS total_customers,  -- Ensure customers are counted only once
    SUM(cp.total_spent) AS total_revenue,
    ROUND(AVG(cp.avg_spending_per_order), 2) AS avg_spend_per_order,  -- Rounded to 2 decimal places
    SUM(CASE WHEN cr.risk_level = 'High Risk' THEN 1 ELSE 0 END) AS high_risk_customers,
    SUM(CASE WHEN cr.risk_level = 'Moderate Risk' THEN 1 ELSE 0 END) AS moderate_risk_customers,
    SUM(CASE WHEN cr.risk_level = 'Low Risk' THEN 1 ELSE 0 END) AS low_risk_customers,
    ROUND((SUM(CASE WHEN cr.risk_level = 'High Risk' THEN 1 ELSE 0 END) / COUNT(DISTINCT c.customer_id)) * 100, 2) AS high_risk_percentage,
    ROUND((SUM(CASE WHEN cr.risk_level = 'Moderate Risk' THEN 1 ELSE 0 END) / COUNT(DISTINCT c.customer_id)) * 100, 2) AS moderate_risk_percentage,
    ROUND((SUM(CASE WHEN cr.risk_level = 'Low Risk' THEN 1 ELSE 0 END) / COUNT(DISTINCT c.customer_id)) * 100, 2) AS low_risk_percentage  -- Added low risk percentage
FROM customer c
JOIN CustomerPurchaseHistory cp ON c.customer_id = cp.customer_id
JOIN ChurnRisk cr ON c.customer_id = cr.customer_id
GROUP BY c.country
ORDER BY total_revenue DESC;

-- question 7
-- Customer Lifetime Value Modeling: How can you leverage customer data (tenure, purchase history, engagement)
--  to predict the lifetime value of different customer segments? This could inform targeted marketing
-- and loyalty program strategies. Can you observe any common characteristics or purchase patterns among
-- customers who have stopped purchasing?


WITH CustomerTenure AS (
    SELECT 
        c.customer_id,
        DATEDIFF((SELECT MAX(invoice_date) FROM invoice), MIN(i.invoice_date)) AS tenure_days,  -- Calculate tenure in days
        SUM(i.total) AS total_spent,  -- Calculate total spending
        COUNT(i.invoice_id) AS purchase_frequency,  -- Calculate purchase frequency
        MAX(i.invoice_date) AS last_purchase_date  -- Find last purchase date
    FROM customer c
    JOIN invoice i ON c.customer_id = i.customer_id
    GROUP BY c.customer_id
),
CLV AS (
    SELECT 
        customer_id,
        tenure_days,
        total_spent,
        purchase_frequency,
        last_purchase_date,
        CASE 
            WHEN tenure_days > 365 THEN total_spent * 1.5  -- Longer tenure may increase value
            WHEN purchase_frequency >= 5 THEN total_spent * 1.2  -- Frequent buyers may have higher value
            ELSE total_spent  -- Default calculation for others
        END AS predicted_clv
    FROM CustomerTenure
)
SELECT 
    c.customer_id,
    c.first_name,
    c.last_name,
    c.country,
    c.email,
    clv.tenure_days,
    clv.total_spent,
    clv.purchase_frequency,
    clv.predicted_clv,
    CASE 
        WHEN clv.last_purchase_date < DATE_SUB((SELECT MAX(invoice_date) FROM invoice), INTERVAL 6 MONTH) THEN 'Stopped Purchasing'
        ELSE 'Active'
    END AS customer_status
FROM customer c
JOIN CLV clv ON c.customer_id = clv.customer_id
ORDER BY clv.predicted_clv DESC;

-- question 8
-- If data on promotional campaigns (discounts, events, email marketing) is available, how could you 
-- measure their impact on customer acquisition, retention, and overall sales?


WITH NewCustomers AS (
    SELECT 
        c.customer_id, 
        MIN(i.invoice_date) AS first_purchase_date
    FROM customer c
    JOIN invoice i ON c.customer_id = i.customer_id
    WHERE i.invoice_date BETWEEN '2017-01-01' AND '2020-12-31'  -- Campaign period
    GROUP BY c.customer_id
),
RetainedCustomers AS (
    SELECT 
        c.customer_id, 
        COUNT(i.invoice_id) AS purchase_count
    FROM customer c
    JOIN invoice i ON c.customer_id = i.customer_id
    WHERE i.invoice_date BETWEEN '2017-01-01' AND '2020-12-31'  -- Campaign period
    GROUP BY c.customer_id
    HAVING purchase_count > 1  -- Customers with repeat purchases
),
SalesImpact AS (
    SELECT 
        SUM(i.total) AS sales_during_campaign
    FROM invoice i
    WHERE i.invoice_date BETWEEN '2017-01-01' AND '2020-12-31'  -- Campaign period
)
SELECT 
    (SELECT COUNT(*) FROM NewCustomers) AS new_customers_acquired,
    (SELECT COUNT(*) FROM RetainedCustomers) AS retained_customers,
    (SELECT sales_during_campaign FROM SalesImpact) AS sales_during_campaign;

-- Question 10
-- How can you alter the "Albums" table to add a new column named "ReleaseYear" of type INTEGER
-- to store the release year of each album?
ALTER TABLE album ADD COLUMN ReleaseYear INTEGER;
Select
	*
from
	album;
    
-- Question 11
-- Chinook is interested in understanding the purchasing behavior of customers based on their geographical
-- location. They want to know the average total amount spent by customers from each country,
-- along with the number of customers and the average number of tracks purchased per customer. 
-- Write an SQL query to provide this information.
SELECT 
    c.country,
    COUNT(DISTINCT c.customer_id) AS total_customers,
    ROUND(SUM(i.total), 2) AS total_amount_spent,
    ROUND(AVG(i.total), 2) AS avg_amount_spent_per_customer,
    ROUND(SUM(il.quantity) / COUNT(DISTINCT c.customer_id), 0) AS avg_tracks_purchased_per_customer
FROM customer c
JOIN invoice i ON c.customer_id = i.customer_id
JOIN invoice_line il ON i.invoice_id = il.invoice_id
GROUP BY c.country
ORDER BY total_amount_spent DESC;


